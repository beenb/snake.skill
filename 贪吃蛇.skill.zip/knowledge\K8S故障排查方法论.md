# Kubernetes 集群故障排查方法论

## 基本信息
- 类型: 公开对象（技术方法论）
- 路由: A. 公开对象路线 → 多Agent并行收集（官方+社区+工具链）
- 蒸馏日期: 2026-04-23

## 核心机制
1. 分层诊断法：用户请求→Service→Pod→Node→集群基础设施
2. 日志即真相：kubectl logs + kubectl describe 是第一反应
3. 五维故障分类：Pod级/Node级/Network级/Storage级/Control Plane级
4. 可观测性三角：Metrics + Logs + Traces
5. 自动化优先：重复性排查必须脚本化

## 高频故障 Top 10
1. OOMKilled
2. CrashLoopBackOff
3. DNS 解析失败
4. ImagePullBackOff
5. Pod Pending
6. Service 无 Endpoints
7. etcd 磁盘写满
8. NetworkPolicy 误拦截
9. kubelet 驱逐风暴
10. API Server 响应慢

## 社区经典口诀
- "DNS 的问题，80% 不是 DNS 的问题"
- "Pending 的 Pod，先看 Node 资源，再看调度策略"
- "OOM 不一定是内存泄漏，可能是 limits 设太低"
- "Service 访问不通，先查 Endpoints，再查 NetworkPolicy"
- "大集群的慢，大概率是 etcd"

## 推荐工具栈
| 类别 | 工具 |
|------|------|
| kubectl 插件 | kubectl-debug, kubectl-trace, kubectl-who-can, krew |
| 监控告警 | Prometheus + Grafana + AlertManager |
| 日志 | Loki / ELK Stack |
| 链路追踪 | Jaeger / Zipkin |
| eBPF | Cilium Hubble, Inspektor Gadget |
| 自动化 | Robusta, BotKube |
| AI辅助 | K8sGPT |

## 能力边界
- 不适用：应用层代码Bug、物理硬件故障、第三方服务故障、安全入侵
- 推荐：集群运维排查决策树、新人培训框架、告警规则设计、自动化脚本编排

## Evidence
- 来源：K8S官方文档 + 社区实战(GitHub/Reddit/掘金/知乎) + 工具链生态
- 可信度：高（多源交叉验证）
- 缺口：超大规模集群(5000+Node)、Serverless K8S、Wasm运行时
